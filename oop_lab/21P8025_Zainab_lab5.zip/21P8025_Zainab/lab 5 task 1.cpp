#include<iostream>
using namespace std;
struct time{
	int hours;
	int minutes;
	int seconds;
};
int myfunction(time t){
	int second;
	second=(t.hours*3600)+(t.minutes*60)+t.seconds;
	return second; 
}

int main(){
   time t;
   cout<<"enter time in hours "<<endl;
   cin>>t.hours;
   cout<<"enter time in minutes "<<endl;
   cin>>t.minutes;
   cout<<"enter time in seconds "<<endl;
   cin>>t.seconds;
    int r;
   r=myfunction(t);
   cout<<"total seconds "<<r;




return 0;	
}
