#include<iostream>
using namespace std;
int main(){
	int a;
	cout<<"enter value of a "<<endl;
    cin>>a;
    int*p=&a;
       
    cout<<"value of a  using pointer "<<" "<<*p<<endl;
    cout<<"address of a  using pointer "<<" "<<p<<endl;
    
    
    
    
return 0;	
}
