#include<iostream>
using namespace std;
int main(){
	int a;
	cout<<"enter size of an array ";
	cin>>a;
	int array[a];
    for(int i=0;i<a;i++){
    	cout<<"Enter value "<<" ["<<i<<"] : " ;
    	cin>>array[i];	}
    int*ptr=array;
    int max=*ptr;
    for(int i=0;i<a;i++){
        if(*ptr>max){
        	max=*ptr;
		}
	 ptr++; }
	 cout<<"maxxium in an array  "<<max;
return 0;	
}
