#include<iostream>
using namespace std;
int main(){
	int a,b;
	cout<<"enter value of a "<<endl;
    cin>>a;
    cout<<"enter value of b  "<<endl;
    cin>>b;
    int*ptrA=&a;
    int*ptrB=&b;
    
    
    cout<<"value of a  using pointer "<<" "<<*ptrA<<endl;
    cout<<"value of b  using pointer "<<" "<<*ptrB<<endl;
    cout<<"address of a  using pointer "<<" "<<ptrA<<endl;
    cout<<"address of b  using pointer "<<" "<<ptrB<<endl;
    
    
    
    
return 0;	
}
